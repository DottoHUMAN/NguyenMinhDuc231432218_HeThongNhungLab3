

#include <WiFi.h>
#include <PubSubClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// ==================================================
// 1. WIFI
// ==================================================

const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ==================================================
// 2. MQTT BROKER
// ==================================================

const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;

#define TOPIC_SENSOR "aquamonitor/esp32_benuoc_2026/sensor"
#define TOPIC_PUMP_CMD "aquamonitor/esp32_benuoc_2026/pump/cmd"
#define TOPIC_VALVE_CMD "aquamonitor/esp32_benuoc_2026/valve/cmd"

#define TOPIC_PUMP_STATE "aquamonitor/esp32_benuoc_2026/pump/state"
#define TOPIC_VALVE_STATE "aquamonitor/esp32_benuoc_2026/valve/state"

// ==================================================
// 3. GPIO - THEO SO DO WOKWI
// ==================================================

// HC-SR04
#define TRIG_PIN 19
#define ECHO_PIN 18

// DS18B20
#define TEMP_PIN 14

// LED
#define LED_BOM_PIN 26
#define LED_VAN_PIN 27

// RELAY
#define BOM_PIN 25
#define VAN_PIN 33

// Relay kich muc LOW
#define RELAY_ACTIVE_LOW true

// Chieu cao be nuoc
#define TANK_HEIGHT 2.0

// ==================================================
// 4. SENSOR
// ==================================================

OneWire oneWire(TEMP_PIN);
DallasTemperature sensors(&oneWire);

// ==================================================
// 5. WIFI AND MQTT
// ==================================================

WiFiClient espClient;
PubSubClient client(espClient);

// ==================================================
// 6. DATA STRUCTURE
// ==================================================

struct SensorData {
  float waterLevel;
  float temperature;
};

// ==================================================
// 7. FREERTOS QUEUE
// ==================================================

QueueHandle_t dataQueue;
QueueHandle_t dataAlert;

// ==================================================
// 8. MANUAL CONTROL
// ==================================================

volatile bool manualMode = false;
volatile bool manualPump = false;
volatile bool manualValve = false;
volatile bool autoResetRequested = false;

// ==================================================
// 9. RELAY CONTROL
// ==================================================

void setRelay(int pin, bool state) {
  if (RELAY_ACTIVE_LOW) {
    digitalWrite(pin, state ? LOW : HIGH);
  } else {
    digitalWrite(pin, state ? HIGH : LOW);
  }
}

void controlPump(bool state, int power) {

  setRelay(BOM_PIN, state);

  // LED xanh mo phong cong suat bom
  analogWrite(
    LED_BOM_PIN,
    state ? map(power, 0, 100, 0, 255) : 0
  );

  client.publish(
    TOPIC_PUMP_STATE,
    state ? "ON" : "OFF"
  );
}

void controlValve(bool state) {

  setRelay(VAN_PIN, state);

  digitalWrite(
    LED_VAN_PIN,
    state ? HIGH : LOW
  );

  client.publish(
    TOPIC_VALVE_STATE,
    state ? "ON" : "OFF"
  );
}

void stopAllActuators() {
  controlPump(false, 0);
  controlValve(false);
}

// ==================================================
// 10. READ HC-SR04
// ==================================================

float readWaterLevel() {

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  unsigned long duration =
    pulseIn(ECHO_PIN, HIGH, 30000);

  if (duration == 0) {
    return -1.0;
  }

  float distanceCM =
    duration * 0.0343 / 2.0;

  float distanceM = distanceCM / 100.0;

  float waterLevel =
    TANK_HEIGHT - distanceM;

  if (waterLevel < 0 || waterLevel > TANK_HEIGHT) {
    return -1.0;
  }

  return waterLevel;
}

// ==================================================
// 11. MQTT CALLBACK
// ==================================================

void mqttCallback(
  char* topic,
  byte* payload,
  unsigned int length
) {

  String message = "";

  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  message.trim();
  message.toUpperCase();

  Serial.print("[MQTT] Topic: ");
  Serial.println(topic);

  Serial.print("[MQTT] Command: ");
  Serial.println(message);

  // Dieu khien may bom
  if (strcmp(topic, TOPIC_PUMP_CMD) == 0) {

    if (message == "ON") {
      manualMode = true;
      manualPump = true;
      manualValve = false;
    }

    else if (message == "OFF") {
      manualMode = true;
      manualPump = false;
    }

    else if (message == "AUTO") {
      manualMode = false;
      autoResetRequested = true;
    }
  }

  // Dieu khien van
  else if (strcmp(topic, TOPIC_VALVE_CMD) == 0) {

    if (message == "ON") {
      manualMode = true;
      manualValve = true;
      manualPump = false;
    }

    else if (message == "OFF") {
      manualMode = true;
      manualValve = false;
    }

    else if (message == "AUTO") {
      manualMode = false;
      autoResetRequested = true;
    }
  }
}

// ==================================================
// 12. TASK DOC DU LIEU - CORE 1
// ==================================================

void TaskReadData(void* parameter) {

  SensorData data;

  for (;;) {

    // Doc muc nuoc
    data.waterLevel = readWaterLevel();

    // Doc nhiet do
    sensors.requestTemperatures();

    data.temperature =
      sensors.getTempCByIndex(0);

    // Hien thi Serial Monitor
    Serial.println("\n========== SENSOR DATA ==========");

    if (data.waterLevel >= 0) {
      Serial.print("Muc nuoc: ");
      Serial.print(data.waterLevel, 2);
      Serial.println(" m");
    } else {
      Serial.println("Loi cam bien muc nuoc!");
    }

    if (data.temperature != DEVICE_DISCONNECTED_C) {
      Serial.print("Nhiet do: ");
      Serial.print(data.temperature, 2);
      Serial.println(" C");
    } else {
      Serial.println("Loi cam bien nhiet do!");
    }

    Serial.println("=================================");

    // Gui du lieu vao dataQueue
    xQueueOverwrite(dataQueue, &data);

    // Gui muc nuoc vao dataAlert
    if (data.waterLevel >= 0) {
      xQueueOverwrite(dataAlert, &data.waterLevel);
    }

    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}

// ==================================================
// 13. TASK TRUYEN DU LIEU - CORE 0
// ==================================================

void TaskSendData(void* parameter) {

  SensorData receivedData;

  for (;;) {

    // Ket noi WiFi
    if (WiFi.status() != WL_CONNECTED) {

      Serial.println("[WIFI] Dang ket noi...");

      WiFi.begin(ssid, password);

      while (WiFi.status() != WL_CONNECTED) {
        vTaskDelay(pdMS_TO_TICKS(500));
      }

      Serial.println("[WIFI] Da ket noi!");
      Serial.println(WiFi.localIP());
    }

    // Ket noi MQTT
    if (!client.connected()) {

      Serial.println("[MQTT] Dang ket noi...");

      String clientId = "ESP32-AQUA-";
      clientId += String(
        (uint32_t)ESP.getEfuseMac(), HEX
      );

      if (client.connect(clientId.c_str())) {

        Serial.println("[MQTT] Da ket noi!");

        client.subscribe(TOPIC_PUMP_CMD);
        client.subscribe(TOPIC_VALVE_CMD);

      } else {

        Serial.print("[MQTT] Loi: ");
        Serial.println(client.state());

        vTaskDelay(pdMS_TO_TICKS(2000));
        continue;
      }
    }

    // Xu ly MQTT va nhan lenh Web
    client.loop();

    // Doc dataQueue
    if (xQueueReceive(
          dataQueue,
          &receivedData,
          pdMS_TO_TICKS(200)
        ) == pdTRUE) {

      if (receivedData.waterLevel >= 0 &&
          receivedData.temperature != DEVICE_DISCONNECTED_C) {

        char jsonData[150];

        snprintf(
          jsonData,
          sizeof(jsonData),
          "{\"water_level\":%.2f,\"temperature\":%.2f}",
          receivedData.waterLevel,
          receivedData.temperature
        );

        // Gui du lieu len MQTT Broker
        client.publish(TOPIC_SENSOR, jsonData);

        Serial.print("[MQTT] Published: ");
        Serial.println(jsonData);
      }
    }

    client.loop();

    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

// ==================================================
// 14. TASK CANH BAO - CORE 1
// ==================================================

void TaskAlert(void* parameter) {

  float waterLevel = -1.0;
  float newestLevel;

  int currentZone = -1;

  bool actionActive = false;

  unsigned long actionStart = 0;
  unsigned long actionDuration = 0;

  for (;;) {

    // Doc du lieu tu dataAlert
    if (xQueueReceive(
          dataAlert,
          &newestLevel,
          pdMS_TO_TICKS(100)
        ) == pdTRUE) {

      waterLevel = newestLevel;

      // Lay gia tri moi nhat
      while (xQueueReceive(
          dataAlert,
          &newestLevel,
          0
        ) == pdTRUE) {

        waterLevel = newestLevel;
      }

      Serial.print("[ALERT] Muc nuoc: ");
      Serial.print(waterLevel);
      Serial.println(" m");
    }

    // ==============================================
    // CHE DO MANUAL
    // ==============================================

    if (manualMode) {

      actionActive = false;
      currentZone = -1;

      controlPump(manualPump, manualPump ? 100 : 0);
      controlValve(manualValve);

      vTaskDelay(pdMS_TO_TICKS(50));
      continue;
    }

    // ==============================================
    // CHUYEN VE CHE DO AUTO
    // ==============================================

    if (autoResetRequested) {

      autoResetRequested = false;

      currentZone = -1;
      actionActive = false;

      stopAllActuators();
    }

    // ==============================================
    // PHAN VUNG MUC NUOC
    // ==============================================

    int newZone = 0;

    if (waterLevel >= 1.0 && waterLevel < 1.5) {
      newZone = 1;
    }

    else if (waterLevel >= 1.5 && waterLevel <= 2.0) {
      newZone = 2;
    }

    else if (waterLevel >= 0 && waterLevel < 0.5) {
      newZone = 3;
    }

    else if (waterLevel < 0) {
      newZone = -1;
    }

    // ==============================================
    // DIEU KHIEN THEO MUC NUOC
    // ==============================================

    if (newZone != currentZone) {

      currentZone = newZone;

      stopAllActuators();

      actionActive = false;

      // Muc nuoc 1m - 1.5m
      if (newZone == 1) {

        Serial.println("[ALERT] BOM 50% - 10 GIAY");

        controlPump(true, 50);

        actionDuration = 10000;
        actionStart = millis();

        actionActive = true;
      }

      // Muc nuoc 1.5m - 2m
      else if (newZone == 2) {

        Serial.println("[ALERT] BOM 100% - 20 GIAY");

        controlPump(true, 100);

        actionDuration = 20000;
        actionStart = millis();

        actionActive = true;
      }

      // Muc nuoc < 0.5m
      else if (newZone == 3) {

        Serial.println("[ALERT] MO VAN - 10 GIAY");

        controlValve(true);

        actionDuration = 10000;
        actionStart = millis();

        actionActive = true;
      }

      else {

        Serial.println("[ALERT] MUC NUOC BINH THUONG");

        stopAllActuators();
      }
    }

    // ==============================================
    // KET THUC THOI GIAN DIEU KHIEN
    // ==============================================

    if (actionActive &&
        millis() - actionStart >= actionDuration) {

      stopAllActuators();

      actionActive = false;

      Serial.println("[ALERT] HOAN THANH DIEU KHIEN!");
    }

    vTaskDelay(pdMS_TO_TICKS(50));
  }
}

// ==================================================
// 15. SETUP
// ==================================================

void setup() {

  Serial.begin(115200);

  // HC-SR04
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // Relay
  pinMode(BOM_PIN, OUTPUT);
  pinMode(VAN_PIN, OUTPUT);

  // LED
  pinMode(LED_BOM_PIN, OUTPUT);
  pinMode(LED_VAN_PIN, OUTPUT);

  // PWM 8 bit - ESP32 Core 3.x
  analogWriteResolution(LED_BOM_PIN, 8);
  analogWriteResolution(LED_VAN_PIN, 8);

  // Tat thiet bi ban dau
  setRelay(BOM_PIN, false);
  setRelay(VAN_PIN, false);

  analogWrite(LED_BOM_PIN, 0);
  digitalWrite(LED_VAN_PIN, LOW);

  // DS18B20
  sensors.begin();

  // MQTT
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(mqttCallback);
  client.setBufferSize(256);

  // Tao Queue
  dataQueue = xQueueCreate(1, sizeof(SensorData));
  dataAlert = xQueueCreate(1, sizeof(float));

  if (dataQueue == NULL || dataAlert == NULL) {

    Serial.println("ERROR: KHONG TAO DUOC QUEUE!");

    while (true) {
      delay(1000);
    }
  }

  Serial.println("\n================================");
  Serial.println(" AQUA MONITORING SYSTEM");
  Serial.println(" ESP32 DEVKIT V1");
  Serial.println(" FREERTOS + MQTT");
  Serial.println("================================");

  // Task doc du lieu - Core 1
  xTaskCreatePinnedToCore(
    TaskReadData,
    "TaskReadData",
    4096,
    NULL,
    2,
    NULL,
    1
  );

  // Task truyen du lieu - Core 0
  xTaskCreatePinnedToCore(
    TaskSendData,
    "TaskSendData",
    6144,
    NULL,
    2,
    NULL,
    0
  );

  // Task canh bao - Core 1
  xTaskCreatePinnedToCore(
    TaskAlert,
    "TaskAlert",
    4096,
    NULL,
    3,
    NULL,
    1
  );
}

// ==================================================
// 16. LOOP
// ==================================================

void loop() {

  vTaskDelay(pdMS_TO_TICKS(1000));

}

