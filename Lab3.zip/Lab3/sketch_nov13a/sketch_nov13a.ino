


#include <WiFi.h>
#include <PubSubClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// ==================================================
// 1. WIFI
// ==================================================

const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ==================================================
// 2. MQTT BROKER
// ==================================================

const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;

#define TOPIC_SENSOR     "aquamonitor/esp32_benuoc_2026/sensor"
#define TOPIC_PUMP_CMD   "aquamonitor/esp32_benuoc_2026/pump/cmd"
#define TOPIC_VALVE_CMD  "aquamonitor/esp32_benuoc_2026/valve/cmd"
#define TOPIC_PUMP_STATE "aquamonitor/esp32_benuoc_2026/pump/state"
#define TOPIC_VALVE_STATE "aquamonitor/esp32_benuoc_2026/valve/state"

// ==================================================
// 3. GPIO - GIU NGUYEN SO DO WOKWI
// ==================================================

// HC-SR04
#define TRIG_PIN 17
#define ECHO_PIN 16

// DS18B20
#define TEMP_PIN 14

// LED
#define LED_BOM_PIN 26
#define LED_VAN_PIN 27

// RELAY
#define BOM_PIN 25
#define VAN_PIN 33

#define RELAY_ACTIVE_LOW true

// Chieu cao be nuoc (met)
#define TANK_HEIGHT 2.0

// ==================================================
// 4. SENSOR
// ==================================================

OneWire oneWire(TEMP_PIN);
DallasTemperature sensors(&oneWire);

// ==================================================
// 5. WIFI + MQTT
// ==================================================

WiFiClient espClient;
PubSubClient client(espClient);

// ==================================================
// 6. DATA STRUCTURE
// ==================================================

struct SensorData {
  float waterLevel;
  float temperature;
};

struct ActuatorState {
  bool pump;
  bool valve;
};

enum CommandType {
  PUMP_ON,
  PUMP_OFF,
  VALVE_ON,
  VALVE_OFF,
  AUTO_MODE
};

// ==================================================
// 7. FREERTOS QUEUE
// ==================================================

QueueHandle_t dataQueue;
QueueHandle_t dataAlert;
QueueHandle_t commandQueue;
QueueHandle_t stateQueue;

// ==================================================
// 8. RELAY CONTROL
// ==================================================

void setRelay(int pin, bool state) {

  if (RELAY_ACTIVE_LOW) {
    digitalWrite(pin, state ? LOW : HIGH);
  } else {
    digitalWrite(pin, state ? HIGH : LOW);
  }
}

// Ham nay chi duoc goi tu TaskAlert

void applyActuators(
  bool pump,
  bool valve,
  int power,
  bool force = false
) {

  static bool lastPump = false;
  static bool lastValve = false;
  static int lastPower = -1;

  if (force ||
      pump != lastPump ||
      valve != lastValve ||
      power != lastPower) {

    setRelay(BOM_PIN, pump);
    setRelay(VAN_PIN, valve);

    analogWrite(
      LED_BOM_PIN,
      pump ? map(power, 0, 100, 0, 255) : 0
    );

    digitalWrite(
      LED_VAN_PIN,
      valve ? HIGH : LOW
    );

    lastPump = pump;
    lastValve = valve;
    lastPower = power;

    ActuatorState state;
    state.pump = pump;
    state.valve = valve;

    if (stateQueue != NULL) {
      xQueueOverwrite(stateQueue, &state);
    }

    Serial.println("[ACTUATOR] Trang thai thay doi");

    Serial.print("May bom: ");
    Serial.println(pump ? "ON" : "OFF");

    Serial.print("Van: ");
    Serial.println(valve ? "ON" : "OFF");
  }
}

void stopAllActuators() {
  applyActuators(false, false, 0);
}

// ==================================================
// 9. READ HC-SR04
// ==================================================

float readWaterLevel() {

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  unsigned long duration =
    pulseIn(ECHO_PIN, HIGH, 30000UL);

  if (duration == 0) {
    Serial.println("[HC-SR04] LOI TIN HIEU ECHO!");
    return -1.0;
  }

  float distanceCM =
    duration * 0.0343 / 2.0;

  float distanceM = distanceCM / 100.0;

  if (distanceM < 0 || distanceM > TANK_HEIGHT) {
    Serial.println("[HC-SR04] KHOANG CACH NGOAI PHAM VI!");
    return -1.0;
  }

  float waterLevel = TANK_HEIGHT - distanceM;

  return waterLevel;
}

// ==================================================
// 10. MQTT CALLBACK
// ==================================================

void mqttCallback(
  char* topic,
  byte* payload,
  unsigned int length
) {

  String message = "";

  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  message.trim();
  message.toUpperCase();

  Serial.print("[MQTT] Topic: ");
  Serial.println(topic);

  Serial.print("[MQTT] Command: ");
  Serial.println(message);

  CommandType command;

  if (strcmp(topic, TOPIC_PUMP_CMD) == 0) {

    if (message == "ON") {
      command = PUMP_ON;
    }
    else if (message == "OFF") {
      command = PUMP_OFF;
    }
    else if (message == "AUTO") {
      command = AUTO_MODE;
    }
    else {
      return;
    }
  }

  else if (strcmp(topic, TOPIC_VALVE_CMD) == 0) {

    if (message == "ON") {
      command = VALVE_ON;
    }
    else if (message == "OFF") {
      command = VALVE_OFF;
    }
    else if (message == "AUTO") {
      command = AUTO_MODE;
    }
    else {
      return;
    }
  }

  else {
    return;
  }

  // Gui lenh sang TaskAlert
  if (xQueueSend(commandQueue, &command, 0) != pdTRUE) {
    Serial.println("[MQTT] HANG DOI LENH DAY!");
  }
}

// ==================================================
// 11. TASK DOC CAM BIEN - CORE 1
// ==================================================

void TaskReadData(void* parameter) {

  SensorData data;

  for (;;) {

    // Doc muc nuoc
    data.waterLevel = readWaterLevel();

    // Doc nhiet do
    sensors.requestTemperatures();

    float temp = sensors.getTempCByIndex(0);

    if (temp == DEVICE_DISCONNECTED_C ||
        temp < -55.0 ||
        temp > 125.0) {

      data.temperature = DEVICE_DISCONNECTED_C;

    } else {

      data.temperature = temp;
    }

    // Hien thi Serial Monitor
    Serial.println();
    Serial.println("========== SENSOR DATA ==========");

    if (data.waterLevel >= 0) {

      Serial.print("Muc nuoc: ");
      Serial.print(data.waterLevel, 2);
      Serial.println(" m");

    } else {

      Serial.println("Loi cam bien muc nuoc!");
    }

    if (data.temperature != DEVICE_DISCONNECTED_C) {

      Serial.print("Nhiet do: ");
      Serial.print(data.temperature, 2);
      Serial.println(" C");

    } else {

      Serial.println("Loi cam bien nhiet do!");
    }

    Serial.println("=================================");

    // Gui du lieu MQTT
    xQueueOverwrite(dataQueue, &data);

    // Luon gui muc nuoc, ke ca khi loi
    xQueueOverwrite(dataAlert, &data.waterLevel);

    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}

// ==================================================
// 12. TASK MQTT - CORE 0
// ==================================================

void TaskSendData(void* parameter) {

  SensorData receivedData;
  ActuatorState actuator;

  bool wifiStarted = false;

  for (;;) {

    // ==============================================
    // WIFI
    // ==============================================

    if (WiFi.status() != WL_CONNECTED) {

      if (!wifiStarted) {

        Serial.println("[WIFI] Dang ket noi...");

        WiFi.mode(WIFI_STA);
        WiFi.begin(ssid, password);

        wifiStarted = true;
      }

      vTaskDelay(pdMS_TO_TICKS(500));
      continue;
    }

    if (WiFi.status() == WL_CONNECTED && wifiStarted) {

      Serial.println("[WIFI] Da ket noi!");
      Serial.print("[WIFI] IP: ");
      Serial.println(WiFi.localIP());

      wifiStarted = false;
    }

    // ==============================================
    // MQTT
    // ==============================================

    if (!client.connected()) {

      Serial.println("[MQTT] Dang ket noi...");

      String clientId = "ESP32-AQUA-";
      clientId += String(
        (uint32_t)ESP.getEfuseMac(), HEX
      );

      if (client.connect(clientId.c_str())) {

        Serial.println("[MQTT] KET NOI THANH CONG!");

        client.subscribe(TOPIC_PUMP_CMD);
        client.subscribe(TOPIC_VALVE_CMD);

      } else {

        Serial.print("[MQTT] Loi ket noi: ");
        Serial.println(client.state());

        vTaskDelay(pdMS_TO_TICKS(2000));
        continue;
      }
    }

    // Nhan lenh MQTT
    client.loop();

    // ==============================================
    // GUI DU LIEU CAM BIEN
    // ==============================================

    if (xQueueReceive(
          dataQueue,
          &receivedData,
          pdMS_TO_TICKS(50)
        ) == pdTRUE) {

      if (receivedData.waterLevel >= 0 ||
          receivedData.temperature != DEVICE_DISCONNECTED_C) {

        char jsonData[200];

        snprintf(
          jsonData,
          sizeof(jsonData),
          "{\"water_level\":%.2f,\"temperature\":%.2f,\"water_error\":%s,\"temp_error\":%s}",
          receivedData.waterLevel,
          receivedData.temperature == DEVICE_DISCONNECTED_C
            ? -127.0 : receivedData.temperature,
          receivedData.waterLevel < 0
            ? "true" : "false",
          receivedData.temperature == DEVICE_DISCONNECTED_C
            ? "true" : "false"
        );

        if (client.publish(TOPIC_SENSOR, jsonData)) {

          Serial.print("[MQTT] Published: ");
          Serial.println(jsonData);

        } else {

          Serial.println("[MQTT] Gui du lieu that bai!");
        }
      }
    }

    // ==============================================
    // GUI TRANG THAI MAY BOM VA VAN
    // ==============================================

    if (xQueueReceive(
          stateQueue,
          &actuator,
          0
        ) == pdTRUE) {

      client.publish(
        TOPIC_PUMP_STATE,
        actuator.pump ? "ON" : "OFF",
        true
      );

      client.publish(
        TOPIC_VALVE_STATE,
        actuator.valve ? "ON" : "OFF",
        true
      );
    }

    client.loop();

    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

// ==================================================
// 13. TASK DIEU KHIEN - CORE 1
// ==================================================

void TaskAlert(void* parameter) {

  float waterLevel = -1.0;
  float newestLevel;

  int currentZone = -1;

  bool manualMode = false;
  bool manualPump = false;
  bool manualValve = false;

  bool actionActive = false;
  bool autoReset = false;

  unsigned long actionStart = 0;
  unsigned long actionDuration = 0;

  bool pumpOutput = false;
  bool valveOutput = false;

  // Tat thiet bi ban dau va cap nhat MQTT state
  applyActuators(false, false, 0, true);

  for (;;) {

    // ==============================================
    // NHAN LENH MANUAL / AUTO
    // ==============================================

    CommandType command;

    while (xQueueReceive(
             commandQueue,
             &command,
             0
           ) == pdTRUE) {

      switch (command) {

        case PUMP_ON:

          manualMode = true;
          manualPump = true;
          manualValve = false;

          Serial.println("[MANUAL] BAT MAY BOM");

          break;

        case PUMP_OFF:

          manualMode = true;
          manualPump = false;

          Serial.println("[MANUAL] TAT MAY BOM");

          break;

        case VALVE_ON:

          manualMode = true;
          manualValve = true;
          manualPump = false;

          Serial.println("[MANUAL] MO VAN");

          break;

        case VALVE_OFF:

          manualMode = true;
          manualValve = false;

          Serial.println("[MANUAL] DONG VAN");

          break;

        case AUTO_MODE:

          manualMode = false;
          autoReset = true;

          Serial.println("[MODE] CHUYEN SANG AUTO");

          break;
      }
    }

    // ==============================================
    // NHAN MUC NUOC MOI NHAT
    // ==============================================

    if (xQueueReceive(
          dataAlert,
          &newestLevel,
          0
        ) == pdTRUE) {

      waterLevel = newestLevel;
    }

    // ==============================================
    // MANUAL MODE
    // ==============================================

    if (manualMode) {

      actionActive = false;
      currentZone = -1;

      pumpOutput = manualPump;
      valveOutput = manualValve;

      applyActuators(
        pumpOutput,
        valveOutput,
        manualPump ? 100 : 0
      );

      vTaskDelay(pdMS_TO_TICKS(50));
      continue;
    }

    // ==============================================
    // RESET KHI CHUYEN SANG AUTO
    // ==============================================

    if (autoReset) {

      autoReset = false;

      currentZone = -1;
      actionActive = false;

      pumpOutput = false;
      valveOutput = false;

      stopAllActuators();
    }

    // ==============================================
    // KIEM TRA CAM BIEN MUC NUOC
    // ==============================================

    if (waterLevel < 0 || waterLevel > TANK_HEIGHT) {

      Serial.println("[ALERT] LOI CAM BIEN - DUNG BOM VA VAN!");

      pumpOutput = false;
      valveOutput = false;

      stopAllActuators();

      actionActive = false;
      currentZone = -1;

      vTaskDelay(pdMS_TO_TICKS(100));
      continue;
    }

    // ==============================================
    // PHAN VUNG MUC NUOC
    // ==============================================

    int newZone = 0;

    // 1.0m den duoi 1.5m
    if (waterLevel >= 1.0 && waterLevel < 1.5) {

      newZone = 1;
    }

    // 1.5m den 2.0m
    else if (waterLevel >= 1.5 && waterLevel <= 2.0) {

      newZone = 2;
    }

    // Duoi 0.5m
    else if (waterLevel >= 0 && waterLevel < 0.5) {

      newZone = 3;
    }

    // 0.5m den duoi 1.0m la binh thuong

    // ==============================================
    // DIEU KHIEN THEO VUNG
    // ==============================================

    if (newZone != currentZone) {

      currentZone = newZone;

      actionActive = false;

      pumpOutput = false;
      valveOutput = false;

      stopAllActuators();

      // VUNG 1: BOM 50% - 10 GIAY
      if (newZone == 1) {

        Serial.println("[AUTO] BOM 50% - 10 GIAY");

        pumpOutput = true;

        applyActuators(true, false, 50);

        actionDuration = 10000;
        actionStart = millis();

        actionActive = true;
      }

      // VUNG 2: BOM 100% - 20 GIAY
      else if (newZone == 2) {

        Serial.println("[AUTO] BOM 100% - 20 GIAY");

        pumpOutput = true;

        applyActuators(true, false, 100);

        actionDuration = 20000;
        actionStart = millis();

        actionActive = true;
      }

      // VUNG 3: MO VAN - 10 GIAY
      else if (newZone == 3) {

        Serial.println("[AUTO] MO VAN - 10 GIAY");

        valveOutput = true;

        applyActuators(false, true, 0);

        actionDuration = 10000;
        actionStart = millis();

        actionActive = true;
      }

      // VUNG BINH THUONG
      else {

        Serial.println("[AUTO] MUC NUOC BINH THUONG");

        stopAllActuators();
      }
    }

    // ==============================================
    // KET THUC THOI GIAN DIEU KHIEN
    // ==============================================

    if (actionActive &&
        millis() - actionStart >= actionDuration) {

      pumpOutput = false;
      valveOutput = false;

      stopAllActuators();

      actionActive = false;

      Serial.println("[AUTO] HOAN THANH DIEU KHIEN!");
    }

    vTaskDelay(pdMS_TO_TICKS(50));
  }
}

// ==================================================
// 14. SETUP
// ==================================================

void setup() {

  Serial.begin(115200);

  // HC-SR04
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  digitalWrite(TRIG_PIN, LOW);

  // Relay
  pinMode(BOM_PIN, OUTPUT);
  pinMode(VAN_PIN, OUTPUT);

  // LED
  pinMode(LED_BOM_PIN, OUTPUT);
  pinMode(LED_VAN_PIN, OUTPUT);

  // PWM - ESP32 Arduino Core 3.x
  analogWriteResolution(LED_BOM_PIN, 8);
  analogWriteResolution(LED_VAN_PIN, 8);

  // Tat thiet bi ban dau
  setRelay(BOM_PIN, false);
  setRelay(VAN_PIN, false);

  analogWrite(LED_BOM_PIN, 0);
  digitalWrite(LED_VAN_PIN, LOW);

  // DS18B20
  sensors.begin();
  sensors.setResolution(12);

  Serial.print("[DS18B20] So cam bien: ");
  Serial.println(sensors.getDeviceCount());

  // MQTT
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(mqttCallback);
  client.setBufferSize(256);
  client.setKeepAlive(30);

  // ==============================================
  // TAO QUEUE
  // ==============================================

  dataQueue = xQueueCreate(
    1,
    sizeof(SensorData)
  );

  dataAlert = xQueueCreate(
    1,
    sizeof(float)
  );

  commandQueue = xQueueCreate(
    5,
    sizeof(CommandType)
  );

  stateQueue = xQueueCreate(
    1,
    sizeof(ActuatorState)
  );

  if (dataQueue == NULL ||
      dataAlert == NULL ||
      commandQueue == NULL ||
      stateQueue == NULL) {

    Serial.println("[ERROR] KHONG TAO DUOC QUEUE!");

    while (true) {
      delay(1000);
    }
  }

  Serial.println();
  Serial.println("==================================");
  Serial.println("      AQUA MONITORING SYSTEM");
  Serial.println("      ESP32 DEVKIT V1");
  Serial.println("      FREERTOS + MQTT");
  Serial.println("==================================");

  // ==============================================
  // TASK DOC CAM BIEN - CORE 1
  // ==============================================

  xTaskCreatePinnedToCore(
    TaskReadData,
    "TaskReadData",
    4096,
    NULL,
    2,
    NULL,
    1
  );

  // ==============================================
  // TASK MQTT - CORE 0
  // ==============================================

  xTaskCreatePinnedToCore(
    TaskSendData,
    "TaskSendData",
    6144,
    NULL,
    2,
    NULL,
    0
  );

  // ==============================================
  // TASK DIEU KHIEN - CORE 1
  // ==============================================

  xTaskCreatePinnedToCore(
    TaskAlert,
    "TaskAlert",
    4096,
    NULL,
    3,
    NULL,
    1
  );
}

// ==================================================
// 15. LOOP
// ==================================================

void loop() {

  vTaskDelay(pdMS_TO_TICKS(1000));

}
